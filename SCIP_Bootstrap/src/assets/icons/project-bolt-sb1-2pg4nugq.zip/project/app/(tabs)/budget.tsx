import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { DollarSign, Users, Calculator, ChartPie as PieChart, TrendingUp, Camera, Music, Utensils, Palette, Car, Gift, Plus, Minus } from 'lucide-react-native';

const { width } = Dimensions.get('window');

const budgetCategories = [
  { icon: Camera, name: 'Photography', percentage: 15, color: '#E8B4B8' },
  { icon: Music, name: 'Music & DJ', percentage: 8, color: '#6B46C1' },
  { icon: Utensils, name: 'Catering', percentage: 40, color: '#F59E0B' },
  { icon: Palette, name: 'Decoration', percentage: 12, color: '#EF4444' },
  { icon: Car, name: 'Transport', percentage: 5, color: '#10B981' },
  { icon: Gift, name: 'Miscellaneous', percentage: 20, color: '#8B5CF6' },
];

export default function BudgetScreen() {
  const [totalBudget, setTotalBudget] = useState('500000');
  const [guestCount, setGuestCount] = useState('150');
  const [showBreakdown, setShowBreakdown] = useState(true);

  const formatCurrency = (amount: string) => {
    return `Rs. ${parseInt(amount).toLocaleString()}`;
  };

  const calculateCategoryBudget = (percentage: number) => {
    const budget = parseInt(totalBudget) || 0;
    return (budget * percentage) / 100;
  };

  const perHeadCost = totalBudget && guestCount ? 
    Math.round(parseInt(totalBudget) / parseInt(guestCount)) : 0;

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Budget Planner</Text>
          <Text style={styles.headerSubtitle}>Plan your wedding expenses smartly</Text>
        </View>

        {/* Budget Input Section */}
        <View style={styles.section}>
          <LinearGradient
            colors={['#6B46C1', '#8B5CF6']}
            style={styles.budgetCard}
          >
            <View style={styles.budgetHeader}>
              <DollarSign size={24} color="#FFFFFF" strokeWidth={2} />
              <Text style={styles.budgetTitle}>Total Wedding Budget</Text>
            </View>
            
            <View style={styles.budgetInputContainer}>
              <Text style={styles.currencySymbol}>Rs.</Text>
              <TextInput
                style={styles.budgetInput}
                value={totalBudget}
                onChangeText={setTotalBudget}
                placeholder="Enter your budget"
                placeholderTextColor="rgba(255, 255, 255, 0.7)"
                keyboardType="numeric"
              />
            </View>

            <View style={styles.guestInputContainer}>
              <Users size={16} color="#FFFFFF" strokeWidth={2} />
              <Text style={styles.guestLabel}>Number of Guests:</Text>
              <TextInput
                style={styles.guestInput}
                value={guestCount}
                onChangeText={setGuestCount}
                placeholder="150"
                placeholderTextColor="rgba(255, 255, 255, 0.7)"
                keyboardType="numeric"
              />
            </View>
          </LinearGradient>
        </View>

        {/* Budget Summary */}
        <View style={styles.section}>
          <View style={styles.summaryContainer}>
            <View style={styles.summaryCard}>
              <Calculator size={20} color="#6B46C1" strokeWidth={2} />
              <Text style={styles.summaryValue}>
                {formatCurrency(totalBudget || '0')}
              </Text>
              <Text style={styles.summaryLabel}>Total Budget</Text>
            </View>
            
            <View style={styles.summaryCard}>
              <Users size={20} color="#E8B4B8" strokeWidth={2} />
              <Text style={styles.summaryValue}>{guestCount || '0'}</Text>
              <Text style={styles.summaryLabel}>Guests</Text>
            </View>
            
            <View style={styles.summaryCard}>
              <TrendingUp size={20} color="#F59E0B" strokeWidth={2} />
              <Text style={styles.summaryValue}>Rs. {perHeadCost.toLocaleString()}</Text>
              <Text style={styles.summaryLabel}>Per Head</Text>
            </View>
          </View>
        </View>

        {/* Budget Breakdown Toggle */}
        <View style={styles.section}>
          <TouchableOpacity
            style={styles.breakdownToggle}
            onPress={() => setShowBreakdown(!showBreakdown)}
          >
            <View style={styles.breakdownHeader}>
              <PieChart size={20} color="#1F2937" strokeWidth={2} />
              <Text style={styles.breakdownTitle}>Budget Breakdown</Text>
            </View>
            <View style={[
              styles.toggleIcon,
              showBreakdown && styles.toggleIconActive
            ]}>
              {showBreakdown ? (
                <Minus size={16} color="#6B46C1" strokeWidth={2} />
              ) : (
                <Plus size={16} color="#6B46C1" strokeWidth={2} />
              )}
            </View>
          </TouchableOpacity>
        </View>

        {/* Budget Categories */}
        {showBreakdown && (
          <View style={styles.section}>
            {budgetCategories.map((category, index) => {
              const categoryBudget = calculateCategoryBudget(category.percentage);
              
              return (
                <View key={index} style={styles.categoryCard}>
                  <View style={styles.categoryHeader}>
                    <View style={styles.categoryInfo}>
                      <View style={[
                        styles.categoryIcon,
                        { backgroundColor: category.color + '20' }
                      ]}>
                        <category.icon
                          size={20}
                          color={category.color}
                          strokeWidth={2}
                        />
                      </View>
                      <View style={styles.categoryDetails}>
                        <Text style={styles.categoryName}>{category.name}</Text>
                        <Text style={styles.categoryPercentage}>
                          {category.percentage}% of total budget
                        </Text>
                      </View>
                    </View>
                    <Text style={styles.categoryAmount}>
                      {formatCurrency(categoryBudget.toString())}
                    </Text>
                  </View>
                  
                  <View style={styles.progressBar}>
                    <View
                      style={[
                        styles.progressFill,
                        {
                          width: `${category.percentage}%`,
                          backgroundColor: category.color,
                        },
                      ]}
                    />
                  </View>
                </View>
              );
            })}
          </View>
        )}

        {/* Budget Tips */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Budget Tips</Text>
          <View style={styles.tipCard}>
            <Text style={styles.tipTitle}>💡 Smart Budgeting</Text>
            <Text style={styles.tipDescription}>
              Allocate 5-10% of your budget as a contingency fund for unexpected expenses.
            </Text>
          </View>
          
          <View style={styles.tipCard}>
            <Text style={styles.tipTitle}>📊 Cost Breakdown</Text>
            <Text style={styles.tipDescription}>
              Catering typically takes 40% of your budget, followed by decoration and photography.
            </Text>
          </View>
        </View>

        {/* Action Buttons */}
        <View style={styles.section}>
          <TouchableOpacity style={styles.primaryButton}>
            <Calculator size={20} color="#FFFFFF" strokeWidth={2} />
            <Text style={styles.primaryButtonText}>Get Detailed Quote</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.secondaryButton}>
            <Text style={styles.secondaryButtonText}>Save Budget Plan</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 20,
  },
  headerTitle: {
    fontSize: 28,
    color: '#1F2937',
    fontFamily: 'Playfair-Bold',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#6B7280',
    fontFamily: 'Inter-Regular',
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  budgetCard: {
    padding: 24,
    borderRadius: 20,
  },
  budgetHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  budgetTitle: {
    fontSize: 18,
    color: '#FFFFFF',
    fontFamily: 'Inter-SemiBold',
    marginLeft: 12,
  },
  budgetInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 12,
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  currencySymbol: {
    fontSize: 24,
    color: '#FFFFFF',
    fontFamily: 'Inter-SemiBold',
    marginRight: 8,
  },
  budgetInput: {
    flex: 1,
    fontSize: 24,
    color: '#FFFFFF',
    fontFamily: 'Inter-Bold',
    paddingVertical: 16,
  },
  guestInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  guestLabel: {
    fontSize: 14,
    color: '#FFFFFF',
    fontFamily: 'Inter-Regular',
    marginLeft: 8,
    marginRight: 12,
  },
  guestInput: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    fontSize: 14,
    color: '#FFFFFF',
    fontFamily: 'Inter-SemiBold',
    minWidth: 60,
  },
  summaryContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  summaryCard: {
    flex: 1,
    backgroundColor: '#F9FAFB',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginHorizontal: 4,
  },
  summaryValue: {
    fontSize: 16,
    color: '#1F2937',
    fontFamily: 'Inter-Bold',
    marginTop: 8,
    marginBottom: 4,
  },
  summaryLabel: {
    fontSize: 12,
    color: '#6B7280',
    fontFamily: 'Inter-Regular',
  },
  breakdownToggle: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    padding: 16,
    borderRadius: 12,
  },
  breakdownHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  breakdownTitle: {
    fontSize: 16,
    color: '#1F2937',
    fontFamily: 'Inter-SemiBold',
    marginLeft: 12,
  },
  toggleIcon: {
    width: 32,
    height: 32,
    backgroundColor: '#E5E7EB',
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  toggleIconActive: {
    backgroundColor: '#E8B4B8',
  },
  categoryCard: {
    backgroundColor: '#F9FAFB',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
  },
  categoryHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  categoryInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  categoryIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  categoryDetails: {
    flex: 1,
  },
  categoryName: {
    fontSize: 16,
    color: '#1F2937',
    fontFamily: 'Inter-SemiBold',
    marginBottom: 2,
  },
  categoryPercentage: {
    fontSize: 12,
    color: '#6B7280',
    fontFamily: 'Inter-Regular',
  },
  categoryAmount: {
    fontSize: 16,
    color: '#1F2937',
    fontFamily: 'Inter-Bold',
  },
  progressBar: {
    height: 4,
    backgroundColor: '#E5E7EB',
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 2,
  },
  sectionTitle: {
    fontSize: 20,
    color: '#1F2937',
    fontFamily: 'Playfair-SemiBold',
    marginBottom: 16,
  },
  tipCard: {
    backgroundColor: '#F0F9FF',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderLeftWidth: 4,
    borderLeftColor: '#0EA5E9',
  },
  tipTitle: {
    fontSize: 14,
    color: '#1F2937',
    fontFamily: 'Inter-SemiBold',
    marginBottom: 4,
  },
  tipDescription: {
    fontSize: 14,
    color: '#6B7280',
    fontFamily: 'Inter-Regular',
    lineHeight: 20,
  },
  primaryButton: {
    backgroundColor: '#6B46C1',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderRadius: 12,
    marginBottom: 12,
  },
  primaryButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    marginLeft: 8,
  },
  secondaryButton: {
    backgroundColor: '#F9FAFB',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  secondaryButtonText: {
    color: '#1F2937',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
});