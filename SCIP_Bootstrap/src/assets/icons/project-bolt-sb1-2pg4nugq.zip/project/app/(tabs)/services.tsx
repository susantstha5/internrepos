import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Image,
  Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  Search,
  Filter,
  Star,
  MapPin,
  Heart,
  Camera,
  Music,
  Utensils,
  Palette,
  Users,
  Car,
  Gift,
  Shirt,
} from 'lucide-react-native';

const { width } = Dimensions.get('window');

const categories = [
  { icon: Camera, name: 'Photography', count: 45 },
  { icon: Music, name: 'Music & DJ', count: 32 },
  { icon: Utensils, name: 'Catering', count: 78 },
  { icon: Palette, name: 'Decoration', count: 56 },
  { icon: Users, name: 'Makeup', count: 34 },
  { icon: Car, name: 'Transport', count: 23 },
  { icon: Gift, name: 'Gifts', count: 19 },
  { icon: Shirt, name: 'Fashion', count: 41 },
];

const vendors = [
  {
    id: 1,
    name: 'Shutter Magic Photography',
    category: 'Photography',
    image: 'https://images.pexels.com/photos/1444442/pexels-photo-1444442.jpeg',
    rating: 4.9,
    reviews: 234,
    location: 'Kathmandu',
    price: 'Rs. 80,000',
    featured: true,
    liked: false,
  },
  {
    id: 2,
    name: 'Royal Feast Catering',
    category: 'Catering',
    image: 'https://images.pexels.com/photos/1395967/pexels-photo-1395967.jpeg',
    rating: 4.8,
    reviews: 189,
    location: 'Pokhara',
    price: 'Rs. 1,200/plate',
    featured: false,
    liked: true,
  },
  {
    id: 3,
    name: 'Divine Decorations',
    category: 'Decoration',
    image: 'https://images.pexels.com/photos/1616113/pexels-photo-1616113.jpeg',
    rating: 4.9,
    reviews: 156,
    location: 'Lalitpur',
    price: 'Rs. 50,000',
    featured: true,
    liked: false,
  },
  {
    id: 4,
    name: 'Melody Masters',
    category: 'Music & DJ',
    image: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg',
    rating: 4.7,
    reviews: 203,
    location: 'Kathmandu',
    price: 'Rs. 25,000',
    featured: false,
    liked: true,
  },
];

export default function ServicesScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [likedVendors, setLikedVendors] = useState(new Set([2, 4]));

  const toggleLike = (vendorId: number) => {
    const newLikedVendors = new Set(likedVendors);
    if (newLikedVendors.has(vendorId)) {
      newLikedVendors.delete(vendorId);
    } else {
      newLikedVendors.add(vendorId);
    }
    setLikedVendors(newLikedVendors);
  };

  const filteredVendors = vendors.filter(vendor => {
    const matchesSearch = vendor.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         vendor.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || vendor.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Services</Text>
          <Text style={styles.headerSubtitle}>Find the perfect vendors for your wedding</Text>
        </View>

        {/* Search Bar */}
        <View style={styles.searchContainer}>
          <View style={styles.searchBar}>
            <Search size={20} color="#9CA3AF" strokeWidth={2} />
            <TextInput
              style={styles.searchInput}
              placeholder="Search vendors, services..."
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholderTextColor="#9CA3AF"
            />
          </View>
          <TouchableOpacity style={styles.filterButton}>
            <Filter size={20} color="#6B46C1" strokeWidth={2} />
          </TouchableOpacity>
        </View>

        {/* Categories */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Categories</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <TouchableOpacity
              style={[
                styles.categoryChip,
                selectedCategory === 'All' && styles.categoryChipActive
              ]}
              onPress={() => setSelectedCategory('All')}
            >
              <Text style={[
                styles.categoryChipText,
                selectedCategory === 'All' && styles.categoryChipTextActive
              ]}>
                All
              </Text>
            </TouchableOpacity>
            {categories.map((category, index) => (
              <TouchableOpacity
                key={index}
                style={[
                  styles.categoryChip,
                  selectedCategory === category.name && styles.categoryChipActive
                ]}
                onPress={() => setSelectedCategory(category.name)}
              >
                <category.icon 
                  size={16} 
                  color={selectedCategory === category.name ? '#FFFFFF' : '#6B7280'} 
                  strokeWidth={2} 
                />
                <Text style={[
                  styles.categoryChipText,
                  selectedCategory === category.name && styles.categoryChipTextActive
                ]}>
                  {category.name}
                </Text>
                <View style={[
                  styles.categoryCount,
                  selectedCategory === category.name && styles.categoryCountActive
                ]}>
                  <Text style={[
                    styles.categoryCountText,
                    selectedCategory === category.name && styles.categoryCountTextActive
                  ]}>
                    {category.count}
                  </Text>
                </View>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Vendors List */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>
              {selectedCategory === 'All' ? 'All Vendors' : selectedCategory}
            </Text>
            <Text style={styles.resultCount}>
              {filteredVendors.length} results
            </Text>
          </View>
          
          {filteredVendors.map((vendor) => (
            <TouchableOpacity key={vendor.id} style={styles.vendorCard}>
              <Image source={{ uri: vendor.image }} style={styles.vendorImage} />
              {vendor.featured && (
                <View style={styles.featuredBadge}>
                  <Text style={styles.featuredBadgeText}>Featured</Text>
                </View>
              )}
              <TouchableOpacity
                style={styles.likeButton}
                onPress={() => toggleLike(vendor.id)}
              >
                <Heart
                  size={20}
                  color={likedVendors.has(vendor.id) ? '#EF4444' : '#9CA3AF'}
                  fill={likedVendors.has(vendor.id) ? '#EF4444' : 'transparent'}
                  strokeWidth={2}
                />
              </TouchableOpacity>
              
              <View style={styles.vendorContent}>
                <View style={styles.vendorInfo}>
                  <Text style={styles.vendorName}>{vendor.name}</Text>
                  <Text style={styles.vendorCategory}>{vendor.category}</Text>
                  
                  <View style={styles.vendorMeta}>
                    <View style={styles.ratingContainer}>
                      <Star size={14} color="#F59E0B" fill="#F59E0B" strokeWidth={0} />
                      <Text style={styles.rating}>{vendor.rating}</Text>
                      <Text style={styles.reviews}>({vendor.reviews} reviews)</Text>
                    </View>
                    <View style={styles.locationContainer}>
                      <MapPin size={12} color="#9CA3AF" strokeWidth={2} />
                      <Text style={styles.locationText}>{vendor.location}</Text>
                    </View>
                  </View>
                  
                  <Text style={styles.priceText}>Starting from {vendor.price}</Text>
                </View>
                
                <TouchableOpacity style={styles.contactButton}>
                  <Text style={styles.contactButtonText}>Contact</Text>
                </TouchableOpacity>
              </View>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 20,
  },
  headerTitle: {
    fontSize: 28,
    color: '#1F2937',
    fontFamily: 'Playfair-Bold',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#6B7280',
    fontFamily: 'Inter-Regular',
  },
  searchContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  searchBar: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    paddingHorizontal: 16,
    height: 48,
  },
  searchInput: {
    flex: 1,
    marginLeft: 12,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#1F2937',
  },
  filterButton: {
    width: 48,
    height: 48,
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 12,
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 20,
    color: '#1F2937',
    fontFamily: 'Playfair-SemiBold',
  },
  resultCount: {
    fontSize: 14,
    color: '#6B7280',
    fontFamily: 'Inter-Regular',
  },
  categoryChip: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 12,
  },
  categoryChipActive: {
    backgroundColor: '#6B46C1',
  },
  categoryChipText: {
    fontSize: 14,
    color: '#6B7280',
    fontFamily: 'Inter-Medium',
    marginLeft: 6,
  },
  categoryChipTextActive: {
    color: '#FFFFFF',
  },
  categoryCount: {
    backgroundColor: '#E5E7EB',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 10,
    marginLeft: 8,
  },
  categoryCountActive: {
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
  },
  categoryCountText: {
    fontSize: 12,
    color: '#6B7280',
    fontFamily: 'Inter-SemiBold',
  },
  categoryCountTextActive: {
    color: '#FFFFFF',
  },
  vendorCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    overflow: 'hidden',
  },
  vendorImage: {
    width: '100%',
    height: 200,
  },
  featuredBadge: {
    position: 'absolute',
    top: 16,
    left: 16,
    backgroundColor: '#E8B4B8',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  featuredBadgeText: {
    fontSize: 12,
    color: '#FFFFFF',
    fontFamily: 'Inter-SemiBold',
  },
  likeButton: {
    position: 'absolute',
    top: 16,
    right: 16,
    width: 36,
    height: 36,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  vendorContent: {
    padding: 16,
  },
  vendorInfo: {
    marginBottom: 16,
  },
  vendorName: {
    fontSize: 18,
    color: '#1F2937',
    fontFamily: 'Inter-SemiBold',
    marginBottom: 4,
  },
  vendorCategory: {
    fontSize: 14,
    color: '#E8B4B8',
    fontFamily: 'Inter-Medium',
    marginBottom: 12,
  },
  vendorMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  rating: {
    fontSize: 14,
    color: '#1F2937',
    fontFamily: 'Inter-SemiBold',
    marginLeft: 4,
  },
  reviews: {
    fontSize: 12,
    color: '#6B7280',
    fontFamily: 'Inter-Regular',
    marginLeft: 4,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  locationText: {
    fontSize: 12,
    color: '#6B7280',
    fontFamily: 'Inter-Regular',
    marginLeft: 4,
  },
  priceText: {
    fontSize: 16,
    color: '#1F2937',
    fontFamily: 'Inter-SemiBold',
  },
  contactButton: {
    backgroundColor: '#6B46C1',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  contactButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
});