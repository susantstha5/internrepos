import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  Heart,
  Star,
  MapPin,
  Phone,
  MessageCircle,
  Share,
  Filter,
  Calendar,
} from 'lucide-react-native';

const favoriteVendors = [
  {
    id: 1,
    name: 'Shutter Magic Photography',
    category: 'Photography',
    image: 'https://images.pexels.com/photos/1444442/pexels-photo-1444442.jpeg',
    rating: 4.9,
    reviews: 234,
    location: 'Kathmandu',
    price: 'Rs. 80,000',
    available: true,
    dateAdded: '2 days ago',
  },
  {
    id: 2,
    name: 'Royal Feast Catering',
    category: 'Catering',
    image: 'https://images.pexels.com/photos/1395967/pexels-photo-1395967.jpeg',
    rating: 4.8,
    reviews: 189,
    location: 'Pokhara',
    price: 'Rs. 1,200/plate',
    available: false,
    dateAdded: '1 week ago',
  },
  {
    id: 3,
    name: 'Divine Decorations',
    category: 'Decoration',
    image: 'https://images.pexels.com/photos/1616113/pexels-photo-1616113.jpeg',
    rating: 4.9,
    reviews: 156,
    location: 'Lalitpur',
    price: 'Rs. 50,000',
    available: true,
    dateAdded: '3 days ago',
  },
  {
    id: 4,
    name: 'Melody Masters',
    category: 'Music & DJ',
    image: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg',
    rating: 4.7,
    reviews: 203,
    location: 'Kathmandu',
    price: 'Rs. 25,000',
    available: true,
    dateAdded: '5 days ago',
  },
  {
    id: 5,
    name: 'Elegance Makeup Studio',
    category: 'Makeup & Beauty',
    image: 'https://images.pexels.com/photos/3065209/pexels-photo-3065209.jpeg',
    rating: 4.8,
    reviews: 167,
    location: 'Kathmandu',
    price: 'Rs. 15,000',
    available: true,
    dateAdded: '1 week ago',
  },
];

export default function FavoritesScreen() {
  const [favorites, setFavorites] = useState(favoriteVendors);
  const [filterCategory, setFilterCategory] = useState('All');

  const categories = ['All', 'Photography', 'Catering', 'Decoration', 'Music & DJ', 'Makeup & Beauty'];

  const removeFavorite = (vendorId: number) => {
    setFavorites(favorites.filter(vendor => vendor.id !== vendorId));
  };

  const filteredFavorites = favorites.filter(vendor => 
    filterCategory === 'All' || vendor.category === filterCategory
  );

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Favorites</Text>
          <Text style={styles.headerSubtitle}>Your saved vendors and services</Text>
        </View>

        {/* Stats */}
        <View style={styles.statsContainer}>
          <View style={styles.statCard}>
            <Heart size={20} color="#EF4444" strokeWidth={2} />
            <Text style={styles.statNumber}>{favorites.length}</Text>
            <Text style={styles.statLabel}>Saved</Text>
          </View>
          <View style={styles.statCard}>
            <Calendar size={20} color="#6B46C1" strokeWidth={2} />
            <Text style={styles.statNumber}>
              {favorites.filter(v => v.available).length}
            </Text>
            <Text style={styles.statLabel}>Available</Text>
          </View>
          <View style={styles.statCard}>
            <Star size={20} color="#F59E0B" strokeWidth={2} />
            <Text style={styles.statNumber}>4.8</Text>
            <Text style={styles.statLabel}>Avg Rating</Text>
          </View>
        </View>

        {/* Filter Categories */}
        <View style={styles.filterSection}>
          <View style={styles.filterHeader}>
            <Filter size={16} color="#6B7280" strokeWidth={2} />
            <Text style={styles.filterTitle}>Filter by Category</Text>
          </View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {categories.map((category, index) => (
              <TouchableOpacity
                key={index}
                style={[
                  styles.filterChip,
                  filterCategory === category && styles.filterChipActive
                ]}
                onPress={() => setFilterCategory(category)}
              >
                <Text style={[
                  styles.filterChipText,
                  filterCategory === category && styles.filterChipTextActive
                ]}>
                  {category}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Favorites List */}
        <View style={styles.section}>
          {filteredFavorites.length === 0 ? (
            <View style={styles.emptyState}>
              <Heart size={48} color="#E5E7EB" strokeWidth={2} />
              <Text style={styles.emptyTitle}>No favorites found</Text>
              <Text style={styles.emptyDescription}>
                {filterCategory === 'All' 
                  ? 'Start exploring vendors and add them to your favorites'
                  : `No ${filterCategory.toLowerCase()} vendors in your favorites`
                }
              </Text>
            </View>
          ) : (
            filteredFavorites.map((vendor) => (
              <View key={vendor.id} style={styles.vendorCard}>
                <Image source={{ uri: vendor.image }} style={styles.vendorImage} />
                <View style={styles.availabilityBadge}>
                  <View style={[
                    styles.availabilityDot,
                    { backgroundColor: vendor.available ? '#10B981' : '#EF4444' }
                  ]} />
                  <Text style={styles.availabilityText}>
                    {vendor.available ? 'Available' : 'Booked'}
                  </Text>
                </View>
                
                <TouchableOpacity
                  style={styles.favoriteButton}
                  onPress={() => removeFavorite(vendor.id)}
                >
                  <Heart
                    size={20}
                    color="#EF4444"
                    fill="#EF4444"
                    strokeWidth={2}
                  />
                </TouchableOpacity>

                <View style={styles.vendorContent}>
                  <View style={styles.vendorInfo}>
                    <Text style={styles.vendorName}>{vendor.name}</Text>
                    <Text style={styles.vendorCategory}>{vendor.category}</Text>
                    
                    <View style={styles.vendorMeta}>
                      <View style={styles.ratingContainer}>
                        <Star size={14} color="#F59E0B" fill="#F59E0B" strokeWidth={0} />
                        <Text style={styles.rating}>{vendor.rating}</Text>
                        <Text style={styles.reviews}>({vendor.reviews})</Text>
                      </View>
                      
                      <View style={styles.locationContainer}>
                        <MapPin size={12} color="#9CA3AF" strokeWidth={2} />
                        <Text style={styles.locationText}>{vendor.location}</Text>
                      </View>
                    </View>
                    
                    <Text style={styles.priceText}>Starting from {vendor.price}</Text>
                    <Text style={styles.dateAdded}>Added {vendor.dateAdded}</Text>
                  </View>

                  <View style={styles.actionButtons}>
                    <TouchableOpacity style={styles.actionButton}>
                      <Phone size={16} color="#6B46C1" strokeWidth={2} />
                      <Text style={styles.actionButtonText}>Call</Text>
                    </TouchableOpacity>
                    
                    <TouchableOpacity style={styles.actionButton}>
                      <MessageCircle size={16} color="#6B46C1" strokeWidth={2} />
                      <Text style={styles.actionButtonText}>Message</Text>
                    </TouchableOpacity>
                    
                    <TouchableOpacity style={styles.actionButton}>
                      <Share size={16} color="#6B46C1" strokeWidth={2} />
                      <Text style={styles.actionButtonText}>Share</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            ))
          )}
        </View>

        {/* Quick Actions */}
        {favorites.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Quick Actions</Text>
            <TouchableOpacity style={styles.quickActionCard}>
              <MessageCircle size={20} color="#6B46C1" strokeWidth={2} />
              <Text style={styles.quickActionText}>Contact All Available Vendors</Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.quickActionCard}>
              <Calendar size={20} color="#E8B4B8" strokeWidth={2} />
              <Text style={styles.quickActionText}>Check Availability for My Date</Text>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 20,
  },
  headerTitle: {
    fontSize: 28,
    color: '#1F2937',
    fontFamily: 'Playfair-Bold',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#6B7280',
    fontFamily: 'Inter-Regular',
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  statCard: {
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderRadius: 12,
    flex: 1,
    marginHorizontal: 4,
  },
  statNumber: {
    fontSize: 20,
    color: '#1F2937',
    fontFamily: 'Inter-Bold',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#6B7280',
    fontFamily: 'Inter-Regular',
    marginTop: 4,
  },
  filterSection: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  filterHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  filterTitle: {
    fontSize: 14,
    color: '#6B7280',
    fontFamily: 'Inter-Medium',
    marginLeft: 8,
  },
  filterChip: {
    backgroundColor: '#F9FAFB',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 12,
  },
  filterChipActive: {
    backgroundColor: '#6B46C1',
  },
  filterChipText: {
    fontSize: 14,
    color: '#6B7280',
    fontFamily: 'Inter-Medium',
  },
  filterChipTextActive: {
    color: '#FFFFFF',
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    color: '#1F2937',
    fontFamily: 'Playfair-SemiBold',
    marginBottom: 16,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 48,
  },
  emptyTitle: {
    fontSize: 20,
    color: '#1F2937',
    fontFamily: 'Inter-SemiBold',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyDescription: {
    fontSize: 14,
    color: '#6B7280',
    fontFamily: 'Inter-Regular',
    textAlign: 'center',
    lineHeight: 20,
  },
  vendorCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    overflow: 'hidden',
  },
  vendorImage: {
    width: '100%',
    height: 180,
  },
  availabilityBadge: {
    position: 'absolute',
    top: 16,
    left: 16,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  availabilityDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 6,
  },
  availabilityText: {
    fontSize: 12,
    color: '#1F2937',
    fontFamily: 'Inter-SemiBold',
  },
  favoriteButton: {
    position: 'absolute',
    top: 16,
    right: 16,
    width: 36,
    height: 36,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  vendorContent: {
    padding: 16,
  },
  vendorInfo: {
    marginBottom: 16,
  },
  vendorName: {
    fontSize: 18,
    color: '#1F2937',
    fontFamily: 'Inter-SemiBold',
    marginBottom: 4,
  },
  vendorCategory: {
    fontSize: 14,
    color: '#E8B4B8',
    fontFamily: 'Inter-Medium',
    marginBottom: 12,
  },
  vendorMeta: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  rating: {
    fontSize: 14,
    color: '#1F2937',
    fontFamily: 'Inter-SemiBold',
    marginLeft: 4,
  },
  reviews: {
    fontSize: 12,
    color: '#6B7280',
    fontFamily: 'Inter-Regular',
    marginLeft: 4,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  locationText: {
    fontSize: 12,
    color: '#6B7280',
    fontFamily: 'Inter-Regular',
    marginLeft: 4,
  },
  priceText: {
    fontSize: 16,
    color: '#1F2937',
    fontFamily: 'Inter-SemiBold',
    marginBottom: 4,
  },
  dateAdded: {
    fontSize: 12,
    color: '#9CA3AF',
    fontFamily: 'Inter-Regular',
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F3F4F6',
    paddingVertical: 10,
    borderRadius: 8,
    marginHorizontal: 4,
  },
  actionButtonText: {
    fontSize: 14,
    color: '#6B46C1',
    fontFamily: 'Inter-SemiBold',
    marginLeft: 4,
  },
  quickActionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
  },
  quickActionText: {
    fontSize: 16,
    color: '#1F2937',
    fontFamily: 'Inter-SemiBold',
    marginLeft: 12,
  },
});