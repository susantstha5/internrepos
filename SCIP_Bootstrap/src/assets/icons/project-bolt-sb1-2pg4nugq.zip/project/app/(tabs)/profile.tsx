import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Switch,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { User, Settings, Heart, Calendar, CreditCard, Bell, CircleHelp as HelpCircle, Star, MapPin, CreditCard as Edit, ChevronRight, LogOut, Shield, Share, Bookmark } from 'lucide-react-native';

const menuItems = [
  {
    icon: Calendar,
    title: 'My Bookings',
    subtitle: '3 active bookings',
    color: '#6B46C1',
  },
  {
    icon: Heart,
    title: 'Favorites',
    subtitle: '12 saved vendors',
    color: '#EF4444',
  },
  {
    icon: CreditCard,
    title: 'Payment Methods',
    subtitle: 'Manage cards & payment',
    color: '#10B981',
  },
  {
    icon: Bell,
    title: 'Notifications',
    subtitle: 'Push, email preferences',
    color: '#F59E0B',
  },
];

const supportItems = [
  {
    icon: HelpCircle,
    title: 'Help & Support',
    subtitle: 'FAQs, contact us',
  },
  {
    icon: Shield,
    title: 'Privacy & Security',
    subtitle: 'Data protection settings',
  },
  {
    icon: Share,
    title: 'Invite Friends',
    subtitle: 'Share the app & earn rewards',
  },
  {
    icon: Star,
    title: 'Rate Swastik',
    subtitle: 'Love our app? Rate us!',
  },
];

export default function ProfileScreen() {
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Profile Header */}
        <LinearGradient
          colors={['#E8B4B8', '#F8BBD9']}
          style={styles.profileHeader}
        >
          <View style={styles.profileInfo}>
            <Image
              source={{ uri: 'https://images.pexels.com/photos/3065209/pexels-photo-3065209.jpeg' }}
              style={styles.profileImage}
            />
            <View style={styles.profileDetails}>
              <Text style={styles.profileName}>Priya Sharma</Text>
              <Text style={styles.profileEmail}>priya.sharma@gmail.com</Text>
              <View style={styles.profileLocation}>
                <MapPin size={14} color="rgba(255, 255, 255, 0.8)" strokeWidth={2} />
                <Text style={styles.locationText}>Kathmandu, Nepal</Text>
              </View>
            </View>
            <TouchableOpacity style={styles.editButton}>
              <Edit size={16} color="#6B46C1" strokeWidth={2} />
            </TouchableOpacity>
          </View>
          
          <View style={styles.profileStats}>
            <View style={styles.statItem}>
              <Text style={styles.statNumber}>3</Text>
              <Text style={styles.statLabel}>Bookings</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statNumber}>12</Text>
              <Text style={styles.statLabel}>Favorites</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statNumber}>4.9</Text>
              <Text style={styles.statLabel}>Reviews</Text>
            </View>
          </View>
        </LinearGradient>

        {/* Main Menu */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Account</Text>
          {menuItems.map((item, index) => (
            <TouchableOpacity key={index} style={styles.menuItem}>
              <View style={[styles.menuIcon, { backgroundColor: item.color + '20' }]}>
                <item.icon size={20} color={item.color} strokeWidth={2} />
              </View>
              <View style={styles.menuContent}>
                <Text style={styles.menuTitle}>{item.title}</Text>
                <Text style={styles.menuSubtitle}>{item.subtitle}</Text>
              </View>
              <ChevronRight size={20} color="#9CA3AF" strokeWidth={2} />
            </TouchableOpacity>
          ))}
        </View>

        {/* Quick Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Quick Settings</Text>
          <View style={styles.settingItem}>
            <View style={styles.settingInfo}>
              <Bell size={20} color="#6B46C1" strokeWidth={2} />
              <View style={styles.settingText}>
                <Text style={styles.settingTitle}>Push Notifications</Text>
                <Text style={styles.settingSubtitle}>Get alerts for bookings & updates</Text>
              </View>
            </View>
            <Switch
              value={notificationsEnabled}
              onValueChange={setNotificationsEnabled}
              trackColor={{ false: '#F3F4F6', true: '#E8B4B8' }}
              thumbColor={notificationsEnabled ? '#FFFFFF' : '#9CA3AF'}
            />
          </View>
        </View>

        {/* Wedding Planning */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Wedding Planning</Text>
          <TouchableOpacity style={styles.planningCard}>
            <View style={styles.planningIcon}>
              <Calendar size={24} color="#6B46C1" strokeWidth={2} />
            </View>
            <View style={styles.planningContent}>
              <Text style={styles.planningTitle}>My Wedding Timeline</Text>
              <Text style={styles.planningSubtitle}>Plan your perfect day step by step</Text>
              <View style={styles.progressBar}>
                <View style={styles.progressFill} />
              </View>
              <Text style={styles.progressText}>65% Complete</Text>
            </View>
          </TouchableOpacity>
        </View>

        {/* Support & More */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Support & More</Text>
          {supportItems.map((item, index) => (
            <TouchableOpacity key={index} style={styles.menuItem}>
              <View style={styles.menuIcon}>
                <item.icon size={20} color="#6B7280" strokeWidth={2} />
              </View>
              <View style={styles.menuContent}>
                <Text style={styles.menuTitle}>{item.title}</Text>
                <Text style={styles.menuSubtitle}>{item.subtitle}</Text>
              </View>
              <ChevronRight size={20} color="#9CA3AF" strokeWidth={2} />
            </TouchableOpacity>
          ))}
        </View>

        {/* App Info */}
        <View style={styles.section}>
          <View style={styles.appInfo}>
            <Text style={styles.appName}>Swastik Event Management</Text>
            <Text style={styles.appVersion}>Version 1.0.0</Text>
            <Text style={styles.appDescription}>
              Empowering women entrepreneurs in Nepal's wedding industry
            </Text>
          </View>
        </View>

        {/* Logout */}
        <View style={styles.section}>
          <TouchableOpacity style={styles.logoutButton}>
            <LogOut size={20} color="#EF4444" strokeWidth={2} />
            <Text style={styles.logoutText}>Sign Out</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  profileHeader: {
    padding: 24,
    marginBottom: 24,
  },
  profileInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 24,
  },
  profileImage: {
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 3,
    borderColor: '#FFFFFF',
  },
  profileDetails: {
    flex: 1,
    marginLeft: 16,
  },
  profileName: {
    fontSize: 22,
    color: '#FFFFFF',
    fontFamily: 'Playfair-Bold',
    marginBottom: 4,
  },
  profileEmail: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.9)',
    fontFamily: 'Inter-Regular',
    marginBottom: 6,
  },
  profileLocation: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  locationText: {
    fontSize: 12,
    color: 'rgba(255, 255, 255, 0.8)',
    fontFamily: 'Inter-Regular',
    marginLeft: 4,
  },
  editButton: {
    width: 36,
    height: 36,
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  profileStats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  statItem: {
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 24,
    color: '#FFFFFF',
    fontFamily: 'Inter-Bold',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: 'rgba(255, 255, 255, 0.8)',
    fontFamily: 'Inter-Regular',
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    color: '#1F2937',
    fontFamily: 'Playfair-SemiBold',
    marginBottom: 16,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
  },
  menuIcon: {
    width: 40,
    height: 40,
    backgroundColor: '#E5E7EB',
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  menuContent: {
    flex: 1,
  },
  menuTitle: {
    fontSize: 16,
    color: '#1F2937',
    fontFamily: 'Inter-SemiBold',
    marginBottom: 2,
  },
  menuSubtitle: {
    fontSize: 12,
    color: '#6B7280',
    fontFamily: 'Inter-Regular',
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#F9FAFB',
    padding: 16,
    borderRadius: 12,
  },
  settingInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  settingText: {
    marginLeft: 16,
    flex: 1,
  },
  settingTitle: {
    fontSize: 16,
    color: '#1F2937',
    fontFamily: 'Inter-SemiBold',
    marginBottom: 2,
  },
  settingSubtitle: {
    fontSize: 12,
    color: '#6B7280',
    fontFamily: 'Inter-Regular',
  },
  planningCard: {
    flexDirection: 'row',
    backgroundColor: '#F9FAFB',
    padding: 20,
    borderRadius: 16,
    alignItems: 'center',
  },
  planningIcon: {
    width: 60,
    height: 60,
    backgroundColor: '#E8B4B8',
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  planningContent: {
    flex: 1,
  },
  planningTitle: {
    fontSize: 18,
    color: '#1F2937',
    fontFamily: 'Inter-SemiBold',
    marginBottom: 4,
  },
  planningSubtitle: {
    fontSize: 14,
    color: '#6B7280',
    fontFamily: 'Inter-Regular',
    marginBottom: 12,
  },
  progressBar: {
    height: 6,
    backgroundColor: '#E5E7EB',
    borderRadius: 3,
    overflow: 'hidden',
    marginBottom: 6,
  },
  progressFill: {
    width: '65%',
    height: '100%',
    backgroundColor: '#6B46C1',
    borderRadius: 3,
  },
  progressText: {
    fontSize: 12,
    color: '#6B46C1',
    fontFamily: 'Inter-SemiBold',
  },
  appInfo: {
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    padding: 24,
    borderRadius: 16,
  },
  appName: {
    fontSize: 18,
    color: '#1F2937',
    fontFamily: 'Playfair-SemiBold',
    marginBottom: 4,
  },
  appVersion: {
    fontSize: 12,
    color: '#6B7280',
    fontFamily: 'Inter-Regular',
    marginBottom: 8,
  },
  appDescription: {
    fontSize: 14,
    color: '#6B7280',
    fontFamily: 'Inter-Regular',
    textAlign: 'center',
    lineHeight: 20,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FEF2F2',
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#FECACA',
  },
  logoutText: {
    fontSize: 16,
    color: '#EF4444',
    fontFamily: 'Inter-SemiBold',
    marginLeft: 8,
  },
});