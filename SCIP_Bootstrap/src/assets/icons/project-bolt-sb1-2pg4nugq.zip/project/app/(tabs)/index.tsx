import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  Bell,
  MapPin,
  Star,
  Users,
  Calendar,
  Sparkles,
  Camera,
  Music,
  Utensils,
  Palette,
} from 'lucide-react-native';

const { width } = Dimensions.get('window');

const services = [
  { icon: Camera, name: 'Photography', color: '#E8B4B8' },
  { icon: Music, name: 'Music & DJ', color: '#6B46C1' },
  { icon: Utensils, name: 'Catering', color: '#F59E0B' },
  { icon: Palette, name: 'Decoration', color: '#EF4444' },
];

const featuredVendors = [
  {
    id: 1,
    name: 'Divine Decorations',
    image: 'https://images.pexels.com/photos/1444442/pexels-photo-1444442.jpeg',
    rating: 4.9,
    reviews: 234,
    location: 'Kathmandu',
    price: 'Rs. 50,000+',
  },
  {
    id: 2,
    name: 'Royal Catering',
    image: 'https://images.pexels.com/photos/1395967/pexels-photo-1395967.jpeg',
    rating: 4.8,
    reviews: 189,
    location: 'Pokhara',
    price: 'Rs. 800/plate',
  },
];

export default function HomeScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.headerContent}>
            <View>
              <Text style={styles.greeting}>Good Morning,</Text>
              <Text style={styles.userName}>Priya ✨</Text>
            </View>
            <TouchableOpacity style={styles.notificationButton}>
              <Bell size={24} color="#6B46C1" strokeWidth={2} />
            </TouchableOpacity>
          </View>
        </View>

        {/* Hero Section */}
        <LinearGradient
          colors={['#E8B4B8', '#F8BBD9']}
          style={styles.heroSection}
        >
          <View style={styles.heroContent}>
            <Text style={styles.heroTitle}>Plan Your Dream Wedding</Text>
            <Text style={styles.heroSubtitle}>
              Connect with the best vendors in Nepal
            </Text>
            <TouchableOpacity style={styles.ctaButton}>
              <Text style={styles.ctaButtonText}>Start Planning</Text>
              <Sparkles size={20} color="#FFFFFF" strokeWidth={2} />
            </TouchableOpacity>
          </View>
        </LinearGradient>

        {/* Quick Stats */}
        <View style={styles.statsContainer}>
          <View style={styles.statCard}>
            <Users size={24} color="#6B46C1" strokeWidth={2} />
            <Text style={styles.statNumber}>500+</Text>
            <Text style={styles.statLabel}>Vendors</Text>
          </View>
          <View style={styles.statCard}>
            <Calendar size={24} color="#E8B4B8" strokeWidth={2} />
            <Text style={styles.statNumber}>1,200+</Text>
            <Text style={styles.statLabel}>Weddings</Text>
          </View>
          <View style={styles.statCard}>
            <Star size={24} color="#F59E0B" strokeWidth={2} />
            <Text style={styles.statNumber}>4.9</Text>
            <Text style={styles.statLabel}>Rating</Text>
          </View>
        </View>

        {/* Services */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Popular Services</Text>
          <View style={styles.servicesGrid}>
            {services.map((service, index) => (
              <TouchableOpacity key={index} style={styles.serviceCard}>
                <View style={[styles.serviceIcon, { backgroundColor: service.color + '20' }]}>
                  <service.icon size={28} color={service.color} strokeWidth={2} />
                </View>
                <Text style={styles.serviceName}>{service.name}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Featured Vendors */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Featured Vendors</Text>
            <TouchableOpacity>
              <Text style={styles.seeAllText}>See All</Text>
            </TouchableOpacity>
          </View>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {featuredVendors.map((vendor) => (
              <TouchableOpacity key={vendor.id} style={styles.vendorCard}>
                <Image source={{ uri: vendor.image }} style={styles.vendorImage} />
                <View style={styles.vendorInfo}>
                  <Text style={styles.vendorName}>{vendor.name}</Text>
                  <View style={styles.vendorMeta}>
                    <View style={styles.ratingContainer}>
                      <Star size={12} color="#F59E0B" fill="#F59E0B" strokeWidth={0} />
                      <Text style={styles.rating}>{vendor.rating}</Text>
                      <Text style={styles.reviews}>({vendor.reviews})</Text>
                    </View>
                  </View>
                  <View style={styles.vendorLocation}>
                    <MapPin size={12} color="#9CA3AF" strokeWidth={2} />
                    <Text style={styles.locationText}>{vendor.location}</Text>
                  </View>
                  <Text style={styles.priceText}>{vendor.price}</Text>
                </View>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Wedding Tips */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Wedding Planning Tips</Text>
          <View style={styles.tipCard}>
            <View style={styles.tipIcon}>
              <Sparkles size={20} color="#6B46C1" strokeWidth={2} />
            </View>
            <View style={styles.tipContent}>
              <Text style={styles.tipTitle}>Start Early, Stay Organized</Text>
              <Text style={styles.tipDescription}>
                Begin planning 12-18 months ahead for the perfect wedding
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  greeting: {
    fontSize: 16,
    color: '#6B7280',
    fontFamily: 'Inter-Regular',
  },
  userName: {
    fontSize: 24,
    color: '#1F2937',
    fontFamily: 'Playfair-Bold',
    marginTop: 4,
  },
  notificationButton: {
    width: 48,
    height: 48,
    backgroundColor: '#F3F4F6',
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  heroSection: {
    marginHorizontal: 20,
    borderRadius: 20,
    padding: 24,
    marginBottom: 24,
  },
  heroContent: {
    alignItems: 'center',
  },
  heroTitle: {
    fontSize: 28,
    color: '#FFFFFF',
    fontFamily: 'Playfair-Bold',
    textAlign: 'center',
    marginBottom: 8,
  },
  heroSubtitle: {
    fontSize: 16,
    color: '#FFFFFF',
    fontFamily: 'Inter-Regular',
    textAlign: 'center',
    opacity: 0.9,
    marginBottom: 24,
  },
  ctaButton: {
    backgroundColor: '#6B46C1',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 25,
    flexDirection: 'row',
    alignItems: 'center',
  },
  ctaButtonText: {
    color: '#FFFFFF',
    fontFamily: 'Inter-SemiBold',
    fontSize: 16,
    marginRight: 8,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingHorizontal: 20,
    marginBottom: 32,
  },
  statCard: {
    alignItems: 'center',
    backgroundColor: '#F9FAFB',
    paddingVertical: 20,
    paddingHorizontal: 24,
    borderRadius: 16,
    flex: 1,
    marginHorizontal: 4,
  },
  statNumber: {
    fontSize: 24,
    color: '#1F2937',
    fontFamily: 'Inter-Bold',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 12,
    color: '#6B7280',
    fontFamily: 'Inter-Regular',
    marginTop: 4,
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 32,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 20,
    color: '#1F2937',
    fontFamily: 'Playfair-SemiBold',
    marginBottom: 16,
  },
  seeAllText: {
    fontSize: 14,
    color: '#E8B4B8',
    fontFamily: 'Inter-SemiBold',
  },
  servicesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  serviceCard: {
    width: (width - 60) / 2,
    backgroundColor: '#F9FAFB',
    padding: 20,
    borderRadius: 16,
    alignItems: 'center',
    marginBottom: 16,
  },
  serviceIcon: {
    width: 60,
    height: 60,
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  serviceName: {
    fontSize: 14,
    color: '#1F2937',
    fontFamily: 'Inter-SemiBold',
    textAlign: 'center',
  },
  vendorCard: {
    width: 200,
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    marginRight: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  vendorImage: {
    width: '100%',
    height: 120,
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
  },
  vendorInfo: {
    padding: 16,
  },
  vendorName: {
    fontSize: 16,
    color: '#1F2937',
    fontFamily: 'Inter-SemiBold',
    marginBottom: 8,
  },
  vendorMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  rating: {
    fontSize: 12,
    color: '#1F2937',
    fontFamily: 'Inter-SemiBold',
    marginLeft: 4,
  },
  reviews: {
    fontSize: 12,
    color: '#6B7280',
    fontFamily: 'Inter-Regular',
    marginLeft: 2,
  },
  vendorLocation: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  locationText: {
    fontSize: 12,
    color: '#6B7280',
    fontFamily: 'Inter-Regular',
    marginLeft: 4,
  },
  priceText: {
    fontSize: 14,
    color: '#E8B4B8',
    fontFamily: 'Inter-SemiBold',
  },
  tipCard: {
    backgroundColor: '#F3F4F6',
    padding: 20,
    borderRadius: 16,
    flexDirection: 'row',
    alignItems: 'center',
  },
  tipIcon: {
    width: 48,
    height: 48,
    backgroundColor: '#E8B4B8',
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  tipContent: {
    flex: 1,
  },
  tipTitle: {
    fontSize: 16,
    color: '#1F2937',
    fontFamily: 'Inter-SemiBold',
    marginBottom: 4,
  },
  tipDescription: {
    fontSize: 14,
    color: '#6B7280',
    fontFamily: 'Inter-Regular',
    lineHeight: 20,
  },
});